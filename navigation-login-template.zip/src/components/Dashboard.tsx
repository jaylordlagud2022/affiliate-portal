import React, { useState } from 'react';
import Navigation from './Navigation';
import DashboardContent from './DashboardContent';
import AccountPage from './AccountPage';

interface DashboardProps {
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onLogout }) => {
  const [currentPage, setCurrentPage] = useState<'dashboard' | 'account'>('dashboard');

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation 
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onLogout={onLogout}
      />
      
      <div className="pt-16">
        {currentPage === 'dashboard' ? (
          <DashboardContent />
        ) : (
          <AccountPage />
        )}
      </div>
    </div>
  );
};

export default Dashboard;