import React, { useState, useEffect } from 'react';
import DashboardService from '../services/dashboardService';

const DashboardContent: React.FC = () => {
  const [stats, setStats] = useState({
    totalCommissions: 0,
    pendingCommissions: 0,
    totalReferrals: 0,
    conversionRate: 0,
  });
  const [activity, setActivity] = useState<any[]>([]);
  const [referralLink, setReferralLink] = useState('');
  const [loading, setLoading] = useState(true);
  
  const dashboardService = new DashboardService('wordpress'); // or 'hubspot'

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setLoading(true);
    
    // Load stats
    const statsResult = await dashboardService.getDashboardStats();
    if (statsResult.success && statsResult.data) {
      setStats(statsResult.data);
    }
    
    // Load activity
    const activityResult = await dashboardService.getRecentActivity();
    if (activityResult.success && activityResult.data) {
      setActivity(activityResult.data);
    }
    
    // Generate referral link
    const linkResult = await dashboardService.generateReferralLink();
    if (linkResult.success && linkResult.data) {
      setReferralLink(linkResult.data);
    }
    
    setLoading(false);
  };
  if (loading) {
    return (
      <div className="p-8">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Welcome back!</h1>
        <p className="text-gray-600">Here's your affiliate dashboard overview</p>
      </div>

      {/* Dashboard Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-2">Total Commissions</h3>
          <p className="text-3xl font-bold text-green-600 mb-2">${stats.totalCommissions.toFixed(2)}</p>
          <p className="text-sm text-gray-600">Total earnings</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-2">Pending</h3>
          <p className="text-3xl font-bold text-orange-600 mb-2">${stats.pendingCommissions.toFixed(2)}</p>
          <p className="text-sm text-gray-600">Awaiting payment</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-2">Referrals</h3>
          <p className="text-3xl font-bold text-blue-600 mb-2">{stats.totalReferrals}</p>
          <p className="text-sm text-gray-600">Total referrals</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-2">Conversion</h3>
          <p className="text-3xl font-bold text-purple-600 mb-2">{(stats.conversionRate * 100).toFixed(1)}%</p>
          <p className="text-sm text-gray-600">Conversion rate</p>
        </div>
      </div>

      {/* Referral Link */}
      {referralLink && (
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">Your Referral Link</h2>
          <div className="flex items-center space-x-4">
            <input
              type="text"
              value={referralLink}
              readOnly
              className="flex-1 p-3 border border-gray-300 rounded-lg bg-gray-50"
            />
            <button
              onClick={() => navigator.clipboard.writeText(referralLink)}
              className="px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Copy
            </button>
          </div>
        </div>
      )}

      {/* Recent Activity */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-xl font-bold mb-4">Recent Activity</h2>
        <div className="space-y-4">
          {activity.length > 0 ? (
            activity.map((item) => (
              <div key={item.id} className="flex items-center justify-between py-3 border-b last:border-b-0">
                <div>
                  <p className="font-medium">{item.description}</p>
                  {item.amount && (
                    <p className="text-sm text-green-600">${item.amount.toFixed(2)}</p>
                  )}
                </div>
                <span className="text-sm text-gray-500">{new Date(item.date).toLocaleDateString()}</span>
              </div>
            ))
          ) : (
            <p className="text-gray-500 text-center py-8">No recent activity</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default DashboardContent;