import React from 'react';

interface NavigationProps {
  currentPage: 'dashboard' | 'account';
  onNavigate: (page: 'dashboard' | 'account') => void;
  onLogout: () => void;
}

const Navigation: React.FC<NavigationProps> = ({ currentPage, onNavigate, onLogout }) => {
  return (
    <nav className="fixed top-0 left-0 right-0 bg-white shadow-sm z-50">
      <div className="max-w-6xl mx-auto px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <h1 className="text-xl font-bold text-gray-800">Affiliate Portal</h1>
            
            <div className="flex space-x-4">
              <button
                onClick={() => onNavigate('dashboard')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  currentPage === 'dashboard'
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
                }`}
              >
                Dashboard
              </button>
              
              <button
                onClick={() => onNavigate('account')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  currentPage === 'account'
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
                }`}
              >
                Account
              </button>
            </div>
          </div>
          
          <button
            onClick={onLogout}
            className="px-4 py-2 text-red-600 hover:text-red-800 hover:bg-red-50 rounded-lg font-medium transition-colors"
          >
            Logout
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;