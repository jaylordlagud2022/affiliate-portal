import React, { useState } from 'react';
import LoginPage from './LoginPage';
import RegisterPage from './RegisterPage';
import Dashboard from './Dashboard';

const AffiliatePortal: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<'home' | 'login' | 'register' | 'dashboard'>('home');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = () => {
    setIsLoggedIn(true);
    setCurrentPage('dashboard');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentPage('home');
  };

  const goBack = () => {
    setCurrentPage('home');
  };

  if (currentPage === 'login') {
    return <LoginPage onLogin={handleLogin} onBack={goBack} />;
  }

  if (currentPage === 'register') {
    return <RegisterPage onBack={goBack} />;
  }

  if (currentPage === 'dashboard' && isLoggedIn) {
    return <Dashboard onLogout={handleLogout} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Section - Portal Access */}
          <div className="bg-white p-8 rounded-lg shadow-sm">
            <h1 className="text-2xl font-bold text-center mb-8">
              AFFILIATE PORTAL<br />ACCESS
            </h1>
            <div className="space-y-4">
              <button
                onClick={() => setCurrentPage('login')}
                className="w-full py-4 px-6 border-2 border-gray-300 rounded-lg text-lg font-semibold hover:bg-gray-50 transition-colors"
              >
                I AM AN AFFILIATE<br />LOG IN
              </button>
              <button
                onClick={() => setCurrentPage('register')}
                className="w-full py-4 px-6 border-2 border-gray-300 rounded-lg text-lg font-semibold hover:bg-gray-50 transition-colors"
              >
                I AM NOT AN AFFILIATE<br />REGISTER
              </button>
            </div>
          </div>

          {/* Middle Section - Register Form Preview */}
          <div className="bg-white p-8 rounded-lg shadow-sm">
            <h2 className="text-2xl font-bold text-center mb-6">Register</h2>
            <div className="space-y-4">
              <input type="text" placeholder="Name" className="w-full p-3 border rounded-lg" disabled />
              <input type="tel" placeholder="Phone" className="w-full p-3 border rounded-lg" disabled />
              <input type="email" placeholder="Email" className="w-full p-3 border rounded-lg" disabled />
              <div className="grid grid-cols-3 gap-2">
                <input type="text" placeholder="Suburb" className="p-3 border rounded-lg" disabled />
                <input type="text" placeholder="State" className="p-3 border rounded-lg" disabled />
                <input type="text" placeholder="Postcode" className="p-3 border rounded-lg" disabled />
              </div>
              <input type="text" placeholder="Business Name" className="w-full p-3 border rounded-lg" disabled />
              <button className="w-full py-3 bg-blue-600 text-white rounded-lg font-semibold" disabled>
                SUBMIT APPLICATION
              </button>
            </div>
          </div>

          {/* Right Section - Activity */}
          <div className="bg-white p-8 rounded-lg shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">AFFILIATE ACTIVITY</h2>
              <button className="text-sm text-gray-600 hover:text-gray-800">GO TO ACCOUNT</button>
            </div>
            
            {/* Progress Steps */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex flex-col items-center">
                <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-white font-bold">✓</div>
                <span className="text-sm mt-1">Registered</span>
              </div>
              <div className="flex-1 h-px bg-gray-300 mx-2"></div>
              <div className="flex flex-col items-center">
                <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-white font-bold">✓</div>
                <span className="text-sm mt-1">Reviewed</span>
              </div>
              <div className="flex-1 h-px bg-gray-300 mx-2"></div>
              <div className="flex flex-col items-center">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">→</div>
                <span className="text-sm mt-1">Approved</span>
              </div>
              <div className="flex-1 h-px bg-gray-300 mx-2"></div>
              <div className="flex flex-col items-center">
                <div className="w-8 h-8 bg-gray-300 rounded-full"></div>
                <span className="text-sm mt-1">Active</span>
              </div>
            </div>

            <div className="text-center mb-6">
              <h3 className="text-xl font-bold mb-2">Thanks for Applying!</h3>
              <p className="text-gray-600 text-sm">
                A member of our team will review your application. If approved, you'll receive your log in details via email.
              </p>
            </div>

            {/* Dashboard Cards */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 border rounded-lg">
                <h4 className="font-bold">Earnings</h4>
                <p className="text-sm text-gray-600">Total rofl earnings and commission</p>
              </div>
              <div className="p-4 border rounded-lg">
                <h4 className="font-bold">Leads</h4>
                <p className="text-sm text-gray-600">Number leads</p>
              </div>
              <div className="p-4 border rounded-lg">
                <h4 className="font-bold">Pipeline</h4>
                <p className="text-sm text-gray-600">Leads in progress</p>
              </div>
              <div className="p-4 border rounded-lg">
                <h4 className="font-bold">Marketing</h4>
                <p className="text-sm text-gray-600">Updates, alerts</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AffiliatePortal;