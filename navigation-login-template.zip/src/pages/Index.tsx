import React from 'react';
import AffiliatePortal from '@/components/AffiliatePortal';

const Index: React.FC = () => {
  return <AffiliatePortal />;
};

export default Index;