import BaseAPI, { ApiType, LoginData, RegisterData, User, ApiResponse } from './api';

class AuthService extends BaseAPI {
  constructor(apiType: ApiType = 'wordpress') {
    super(apiType);
  }

  // WordPress Authentication
  private async wordpressLogin(data: LoginData): Promise<ApiResponse<User>> {
    try {
      const response = await this.makeRequest(`${process.env.REACT_APP_WP_AUTH_URL}/token`, {
        method: 'POST',
        body: JSON.stringify({
          username: data.email,
          password: data.password,
        }),
      });

      const result = await response.json();

      if (response.ok && result.token) {
        localStorage.setItem('authToken', result.token);
        return {
          success: true,
          data: {
            id: result.user_id,
            email: result.user_email,
            name: result.user_display_name,
          },
        };
      }

      return { success: false, error: result.message || 'Login failed' };
    } catch (error) {
      return { success: false, error: 'Network error' };
    }
  }

  // HubSpot Authentication (Contact creation/validation)
  private async hubspotLogin(data: LoginData): Promise<ApiResponse<User>> {
    try {
      // HubSpot doesn't have traditional auth, so we validate contact existence
      const response = await this.makeRequest(
        `https://api.hubapi.com/contacts/v1/contact/email/${data.email}/profile?hapikey=${process.env.REACT_APP_HUBSPOT_API_KEY}`
      );

      if (response.ok) {
        const contact = await response.json();
        // Simple password validation (in real app, use proper auth)
        if (contact.properties?.password?.value === data.password) {
          return {
            success: true,
            data: {
              id: contact.vid.toString(),
              email: contact.properties?.email?.value || data.email,
              name: `${contact.properties?.firstname?.value || ''} ${contact.properties?.lastname?.value || ''}`.trim(),
              phone: contact.properties?.phone?.value,
              businessName: contact.properties?.company?.value,
            },
          };
        }
      }

      return { success: false, error: 'Invalid credentials' };
    } catch (error) {
      return { success: false, error: 'Authentication failed' };
    }
  }

  // Main login method
  async login(data: LoginData): Promise<ApiResponse<User>> {
    if (this.apiType === 'wordpress') {
      return this.wordpressLogin(data);
    } else {
      return this.hubspotLogin(data);
    }
  }

  // WordPress Registration
  private async wordpressRegister(data: RegisterData): Promise<ApiResponse<User>> {
    try {
      const response = await this.makeRequest(`${process.env.REACT_APP_WP_BASE_URL}/users`, {
        method: 'POST',
        body: JSON.stringify({
          username: data.email,
          email: data.email,
          password: data.password || 'temp123',
          name: data.name,
          meta: {
            phone: data.phone,
            business_name: data.businessName,
            suburb: data.suburb,
            state: data.state,
            postcode: data.postcode,
          },
        }),
      });

      const result = await response.json();

      if (response.ok) {
        return {
          success: true,
          data: {
            id: result.id.toString(),
            email: result.email,
            name: result.name,
            phone: data.phone,
            businessName: data.businessName,
            suburb: data.suburb,
            state: data.state,
            postcode: data.postcode,
          },
        };
      }

      return { success: false, error: result.message || 'Registration failed' };
    } catch (error) {
      return { success: false, error: 'Network error' };
    }
  }

  // HubSpot Registration (Contact creation)
  private async hubspotRegister(data: RegisterData): Promise<ApiResponse<User>> {
    try {
      const contactData = {
        properties: [
          { property: 'email', value: data.email },
          { property: 'firstname', value: data.name.split(' ')[0] },
          { property: 'lastname', value: data.name.split(' ').slice(1).join(' ') },
          { property: 'phone', value: data.phone },
          { property: 'company', value: data.businessName },
          { property: 'city', value: data.suburb },
          { property: 'state', value: data.state },
          { property: 'zip', value: data.postcode },
          { property: 'password', value: data.password || 'temp123' }, // Not recommended for production
        ],
      };

      const response = await this.makeRequest(
        `https://api.hubapi.com/contacts/v1/contact?hapikey=${process.env.REACT_APP_HUBSPOT_API_KEY}`,
        {
          method: 'POST',
          body: JSON.stringify(contactData),
        }
      );

      if (response.ok) {
        const result = await response.json();
        return {
          success: true,
          data: {
            id: result.vid.toString(),
            email: data.email,
            name: data.name,
            phone: data.phone,
            businessName: data.businessName,
            suburb: data.suburb,
            state: data.state,
            postcode: data.postcode,
          },
        };
      }

      const error = await response.json();
      return { success: false, error: error.message || 'Registration failed' };
    } catch (error) {
      return { success: false, error: 'Network error' };
    }
  }

  // Main register method
  async register(data: RegisterData): Promise<ApiResponse<User>> {
    if (this.apiType === 'wordpress') {
      return this.wordpressRegister(data);
    } else {
      return this.hubspotRegister(data);
    }
  }

  // Logout
  logout(): void {
    localStorage.removeItem('authToken');
    localStorage.removeItem('currentUser');
  }

  // Check if user is authenticated
  isAuthenticated(): boolean {
    return !!localStorage.getItem('authToken');
  }

  // Get current user from storage
  getCurrentUser(): User | null {
    const userData = localStorage.getItem('currentUser');
    return userData ? JSON.parse(userData) : null;
  }

  // Save current user to storage
  saveCurrentUser(user: User): void {
    localStorage.setItem('currentUser', JSON.stringify(user));
  }
}

export default AuthService;